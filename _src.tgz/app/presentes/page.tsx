import Link from "next/link";

export const metadata = {
  title: "Lista de Presentes · Isa & Rudinei",
};

export default function PresentesPage() {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        padding: "120px clamp(20px,5vw,64px)",
        background: "var(--cream)",
      }}
    >
      <div style={{ maxWidth: 520 }}>
        <p style={{ fontSize: 12, letterSpacing: "0.4em", textTransform: "uppercase", color: "var(--gold)", margin: "0 0 18px" }}>
          LISTA DE PRESENTES
        </p>
        <h1 style={{ fontFamily: "var(--font-cormorant), serif", fontWeight: 300, fontSize: "clamp(38px,5.5vw,56px)", lineHeight: 1.05, margin: 0 }}>
          Em breve
        </h1>
        <p style={{ fontSize: 15, lineHeight: 1.7, color: "var(--muted-2)", margin: "22px 0 36px" }}>
          Estamos preparando a lista completa de presentes — tradicional, cotas de lua de mel e PIX. Volte em breve!
        </p>
        <Link
          href="/"
          style={{
            display: "inline-block",
            background: "var(--gold)",
            color: "#fff",
            fontSize: 12,
            letterSpacing: "0.16em",
            textTransform: "uppercase",
            padding: "16px 36px",
            borderRadius: 2,
          }}
        >
          Voltar ao início
        </Link>
      </div>
    </div>
  );
}
